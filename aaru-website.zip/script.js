(() => {
  const pages = [...document.querySelectorAll(".page")];
  const chapterDots = [...document.querySelectorAll(".chapter-dot")];
  const currentNumber = document.getElementById("currentNumber");
  const previousButton = document.getElementById("previousPage");
  const nextButton = document.getElementById("nextPage");
  const nextLabel = document.getElementById("nextLabel");
  let currentPage = 0;

  function showPage(index) {
    document.querySelectorAll(".chosen-video").forEach((video) => video.pause());
    currentPage = Math.max(0, Math.min(pages.length - 1, index));
    pages.forEach((page, pageIndex) => {
      const isCurrent = pageIndex === currentPage;
      page.classList.toggle("is-current", isCurrent);
      page.setAttribute("aria-hidden", String(!isCurrent));
      if (isCurrent) {
        // Restart the entrance animation each time a chapter is opened.
        page.style.animation = "none";
        void page.offsetWidth;
        page.style.animation = "";
      }
    });
    chapterDots.forEach((dot, dotIndex) => {
      const isCurrent = dotIndex === currentPage;
      dot.classList.toggle("is-active", isCurrent);
      if (isCurrent) dot.setAttribute("aria-current", "step");
      else dot.removeAttribute("aria-current");
    });
    currentNumber.textContent = String(currentPage + 1).padStart(2, "0");
    previousButton.disabled = currentPage === 0;
    nextButton.hidden = currentPage === pages.length - 1;
    nextLabel.textContent = currentPage === 2 ? "The last page" : "Turn the page";
    if (window.matchMedia("(max-width: 680px)").matches) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  previousButton.addEventListener("click", () => showPage(currentPage - 1));
  nextButton.addEventListener("click", () => showPage(currentPage + 1));
  chapterDots.forEach((dot) => dot.addEventListener("click", () => showPage(Number(dot.dataset.page))));
  document.addEventListener("keydown", (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.target.closest("dialog")) return;
    if (event.key === "ArrowRight") showPage(currentPage + 1);
    if (event.key === "ArrowLeft") showPage(currentPage - 1);
  });

  const imageMemory = (filename, alt) => ({
    type: "image",
    src: `./memories/${filename}`,
    alt,
  });
  const memoryGalleries = {
    whereBegan: [
      imageMemory("IMG-20261021-WA0012_1792600840603.jpg", "Aaru in her colorful Garba outfit"),
      imageMemory("IMG-20261021-WA0011_1792600840631.jpg", "Aaru in a festive black and white outfit"),
      imageMemory("IMG-20261021-WA0010_1792600840656.jpg", "Aaru in a classic black and gold look"),
      imageMemory("IMG-20261021-WA0006_1792600840767.jpg", "Aaru in a soft pink outfit"),
      imageMemory("IMG-20261021-WA0007_1792600840738.jpg", "Aaru wearing a pink festive wrap"),
      imageMemory("IMG-20261021-WA0008_1792600840685.jpg", "Aaru in a quiet pink outfit"),
      imageMemory("IMG-20261021-WA0009_1792600840711.jpg", "Aaru's smiling pink portrait"),
      imageMemory("IMG-20261021-WA0017_1792600840504.jpg", "Aaru in a red patterned outfit"),
      imageMemory("IMG-20261021-WA0019_1792600840536.jpg", "Aaru in a floral festive outfit"),
    ],
    throughEyes: [
      imageMemory("IMG-20261021-WA0016_1792600840517.jpg", "Aaru in a floral outfit"),
      imageMemory("IMG-20261021-WA0018_1792600840491.jpg", "Aaru's bright close-up portrait"),
      imageMemory("IMG-20261021-WA0013_1792600840581.jpg", "Aaru wearing her glasses"),
      imageMemory("IMG-20261021-WA0014_1792600840556.jpg", "Aaru in a sunny outdoor portrait"),
      imageMemory("IMG-20261021-WA0015_1792600840477.jpg", "Two playful portrait memories"),
      imageMemory("IMG-20261021-WA0020_1792600840464.jpg", "Aaru's playful double portrait"),
      imageMemory("IMG-20261021-WA0021_1792600840416.jpg", "Aaru cuddling a little kitten"),
      imageMemory("IMG-20261021-WA0024_1792600840433.jpg", "Aaru relaxing in a green outfit"),
      {
        type: "video",
        src: "./memories/our-moment.mp4",
        poster: "./memories/our-moment-poster.jpg",
        alt: "A short video memory of Aaru",
      },
    ],
  };

  function renderMemory(galleryWindow, index) {
    const gallery = memoryGalleries[galleryWindow.dataset.galleryId];
    if (!gallery || gallery.length === 0) return;
    const selectedIndex = (index + gallery.length) % gallery.length;
    const item = gallery[selectedIndex];
    const image = galleryWindow.querySelector(".chosen-photo");
    const video = galleryWindow.querySelector(".chosen-video");
    const counter = galleryWindow.querySelector(".gallery-count");

    galleryWindow.dataset.galleryIndex = String(selectedIndex);
    counter.textContent = `${String(selectedIndex + 1).padStart(2, "0")} / ${String(gallery.length).padStart(2, "0")}`;
    galleryWindow.classList.toggle("is-video", item.type === "video");
    video.pause();

    if (item.type === "video") {
      image.hidden = true;
      video.hidden = false;
      if (video.getAttribute("src") !== item.src) {
        video.src = item.src;
        video.load();
      }
      video.poster = item.poster;
      video.setAttribute("aria-label", item.alt);
    } else {
      video.hidden = true;
      image.hidden = false;
      image.src = item.src;
      image.alt = item.alt;
    }
  }

  document.querySelectorAll(".photo-window[data-gallery-id]").forEach((galleryWindow) => {
    galleryWindow.querySelectorAll(".gallery-arrow").forEach((button) => {
      button.addEventListener("click", () => {
        const currentIndex = Number(galleryWindow.dataset.galleryIndex || 0);
        renderMemory(galleryWindow, currentIndex + Number(button.dataset.direction));
      });
    });
  });

  document.querySelectorAll(".photo-input").forEach((input) => {
    input.addEventListener("change", () => {
      const file = input.files && input.files[0];
      if (!file || !file.type.startsWith("image/")) return;
      const windowElement = input.closest(".photo-window");
      const gallery = memoryGalleries[windowElement.dataset.galleryId];
      const objectUrl = URL.createObjectURL(file);
      gallery.push({
        type: "image",
        src: objectUrl,
        alt: file.name.replace(/\.[^/.]+$/, "") || "A personal memory",
      });
      renderMemory(windowElement, gallery.length - 1);
      input.value = "";
    });
  });

  const answerZone = document.getElementById("answerZone");
  const noZone = document.getElementById("noZone");
  const noButton = document.getElementById("noButton");
  let noHasMoved = false;

  function moveNoButton(event) {
    if (event && event.pointerType === "mouse" && event.type === "pointerdown") return;
    const zone = noZone.getBoundingClientRect();
    const button = noButton.getBoundingClientRect();
    const maxLeft = Math.max(0, zone.width - button.width);
    const maxTop = Math.max(0, zone.height - button.height);
    let left = Math.random() * maxLeft;
    let top = Math.random() * maxTop;
    if (noHasMoved && maxLeft > 1 && Math.abs(left - parseFloat(noButton.style.left || "0")) < maxLeft * .3) {
      left = Math.random() * maxLeft;
    }
    noHasMoved = true;
    noButton.style.left = `${left}px`;
    noButton.style.top = `${top}px`;
    noButton.style.transform = "rotate(" + (Math.random() * 12 - 6).toFixed(1) + "deg)";
  }

  noButton.addEventListener("pointerenter", (event) => {
    if (event.pointerType === "mouse") moveNoButton(event);
  });
  noButton.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    moveNoButton(event);
  });
  noButton.addEventListener("focus", () => moveNoButton());
  noButton.addEventListener("click", (event) => {
    event.preventDefault();
    moveNoButton(event);
  });

  const yesButton = document.getElementById("yesButton");
  const yesModal = document.getElementById("yesModal");
  const closeModal = document.getElementById("closeModal");
  const celebrationLayer = document.getElementById("celebrationLayer");
  const heartSymbols = ["♥", "♡", "💖", "💕", "❤", "✿"];
  const particleColors = ["#c96778", "#e59ba0", "#d78981", "#b97989", "#efb8aa", "#c66f83"];

  function celebrate() {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!reducedMotion) {
      for (let index = 0; index < 100; index += 1) {
        const heart = document.createElement("span");
        heart.className = "confetti-heart";
        heart.textContent = heartSymbols[Math.floor(Math.random() * heartSymbols.length)];
        heart.style.setProperty("--x", `${(Math.random() * 2 - 1) * window.innerWidth * .75}px`);
        heart.style.setProperty("--y", `${(Math.random() * 2 - 1) * window.innerHeight * .75}px`);
        heart.style.setProperty("--spin", `${Math.random() * 150 - 75}deg`);
        heart.style.setProperty("--end-spin", `${Math.random() * 540 - 270}deg`);
        heart.style.setProperty("--particle-size", `${12 + Math.random() * 23}px`);
        heart.style.setProperty("--particle-duration", `${1.2 + Math.random() * 1.2}s`);
        heart.style.setProperty("--particle-color", particleColors[Math.floor(Math.random() * particleColors.length)]);
        celebrationLayer.appendChild(heart);
        window.setTimeout(() => heart.remove(), 2600);
      }
    }
    if (!yesModal.open) yesModal.showModal();
  }

  yesButton.addEventListener("click", celebrate);
  closeModal.addEventListener("click", () => yesModal.close());
  yesModal.addEventListener("click", (event) => {
    if (event.target === yesModal) yesModal.close();
  });
  yesModal.addEventListener("close", () => yesButton.focus());

  showPage(0);
})();
